
Wraps some standard python commands for brevity. Parameters default to the canonical data science use case (or the author's primary use case)

see: https://github.com/TroyRetter/TRU


