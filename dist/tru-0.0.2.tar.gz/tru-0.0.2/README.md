# Tru (Troy's Untilities)

Wraps some standard python commands for brevity.
Parameters default to the canonical data science use case
(or the author's primary use case)

## License

MIT License
